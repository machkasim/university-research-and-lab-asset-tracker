import pyodbc
from contextlib import contextmanager
from config import sql_connection_string


@contextmanager
def get_connection():
    conn = pyodbc.connect(sql_connection_string(), timeout=5, autocommit=False)
    try:
        yield conn
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def fetch_all(sql: str, params=()):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(sql, params)
        columns = [column[0] for column in cur.description]
        return [dict(zip(columns, row)) for row in cur.fetchall()]


def fetch_one(sql: str, params=()):
    rows = fetch_all(sql, params)
    return rows[0] if rows else None
