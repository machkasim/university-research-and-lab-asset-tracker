from __future__ import annotations

import os
import secrets
from datetime import datetime

from flask import Flask, flash, redirect, render_template, request, url_for
from flask_wtf.csrf import CSRFProtect
from dotenv import load_dotenv

from db import get_connection, fetch_all, fetch_one

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET_KEY", "dev-only-change-me")
app.config["WTF_CSRF_TIME_LIMIT"] = 3600
CSRFProtect(app)


def parse_datetime_local(value: str) -> datetime:
    if not value:
        raise ValueError("Vui lòng nhập đầy đủ thời gian.")
    return datetime.fromisoformat(value)


def new_access_log_id() -> str:
    # ACCESS_LOG.Access_Log_ID is VARCHAR(20); this produces 18 characters.
    return "AL" + secrets.token_hex(8).upper()


def safe_db_error(exc: Exception) -> str:
    # Do not expose connection strings, credentials or full database diagnostics in the UI.
    message = str(exc)
    if "5100" in message or "Reservation overlaps" in message or "status prevents" in message:
        return "SQL Server đã từ chối thao tác do vi phạm quy tắc nghiệp vụ. Hãy kiểm tra trạng thái tài nguyên hoặc khoảng thời gian đặt lịch."
    if "valid matching certification" in message or "equipment is available" in message:
        return "Không thể ghi nhận GRANTED vì chứng nhận an toàn không phù hợp hoặc đã hết hiệu lực."
    return "Không thể hoàn thành thao tác. Hãy kiểm tra kết nối SQL Server và dữ liệu đầu vào."


def require_active_person(cur, person_id: str) -> None:
    """Reject a submitted Person_ID unless the referenced PERSON is ACTIVE."""
    cur.execute("SELECT Status FROM dbo.PERSON WHERE Person_ID = ?", person_id)
    row = cur.fetchone()
    if row is None:
        raise ValueError("Không tìm thấy Person đã chọn.")
    if row[0] != "ACTIVE":
        raise ValueError("Chỉ Person có Status = ACTIVE mới được thực hiện thao tác này.")


@app.get("/")
def dashboard():
    try:
        stats = fetch_one("""
            SELECT
              (SELECT COUNT_BIG(*) FROM dbo.LABORATORY) AS laboratory_count,
              (SELECT COUNT_BIG(*) FROM dbo.WORKSTATION) AS workstation_count,
              (SELECT COUNT_BIG(*) FROM dbo.EQUIPMENT) AS equipment_count,
              (SELECT COUNT_BIG(*) FROM dbo.EQUIPMENT WHERE Status='AVAILABLE') AS available_equipment_count,
              (SELECT COUNT_BIG(*) FROM dbo.BORROWS WHERE Actual_Return_Date IS NULL AND Borrow_Status IN ('BORROWED','OVERDUE')) AS open_borrowing_count,
              (SELECT COUNT_BIG(*) FROM dbo.ACCESS_LOG WHERE Access_Result='DENIED') AS denied_access_count
        """)
        recent_logs = fetch_all("""
            SELECT TOP (5) a.Access_Time, p.Full_Name, e.Equipment_Name,
                   a.Action, a.Access_Result, a.Denial_Reason
            FROM dbo.ACCESS_LOG a
            JOIN dbo.PERSON p ON p.Person_ID=a.Person_ID
            JOIN dbo.EQUIPMENT e ON e.Equipment_ID=a.Equipment_ID
            ORDER BY a.Access_Time DESC, a.Access_Log_ID DESC
        """)
        return render_template("dashboard.html", stats=stats, recent_logs=recent_logs)
    except Exception:
        flash("Không kết nối được SQL Server. Kiểm tra file .env, instance và quyền database.", "error")
        return render_template("dashboard.html", stats=None, recent_logs=[])


@app.get("/equipment")
def equipment_list():
    status = request.args.get("status", "")
    lab_id = request.args.get("lab_id", "")
    statuses = {"", "AVAILABLE", "UNDER_MAINTENANCE", "BROKEN", "RETIRED"}
    if status not in statuses:
        flash("Trạng thái lọc không hợp lệ.", "error")
        status = ""
    sql = """
        SELECT TOP (500) e.Equipment_ID, e.Equipment_Name, e.Equipment_Type, e.Manufacturer,
               e.Status, e.Safety_Requirement, l.Lab_Name
        FROM dbo.EQUIPMENT e
        JOIN dbo.LABORATORY l ON l.Lab_ID=e.Lab_ID
        WHERE (? = '' OR e.Status = ?)
          AND (? = '' OR e.Lab_ID = ?)
        ORDER BY e.Equipment_ID
    """
    try:
        rows = fetch_all(sql, (status, status, lab_id, lab_id))
        labs = fetch_all("SELECT Lab_ID, Lab_Name FROM dbo.LABORATORY ORDER BY Lab_Name")
        return render_template("equipment.html", rows=rows, labs=labs, status=status, lab_id=lab_id)
    except Exception:
        flash("Không tải được danh sách Equipment.", "error")
        return render_template("equipment.html", rows=[], labs=[], status=status, lab_id=lab_id)


@app.get("/equipment/<equipment_id>/maintenance")
def maintenance_history(equipment_id):
    try:
        equipment = fetch_one("SELECT Equipment_ID, Equipment_Name FROM dbo.EQUIPMENT WHERE Equipment_ID=?", (equipment_id,))
        if not equipment:
            flash("Không tìm thấy Equipment.", "error")
            return redirect(url_for("equipment_list"))
        rows = fetch_all("""
            SELECT m.Maintenance_ID, m.Maintenance_Date, m.Maintenance_Type,
                   m.Maintenance_Result, m.Description, p.Full_Name AS Staff_Name
            FROM dbo.MAINTENANCE_RECORD m
            JOIN dbo.LAB_STAFF s ON s.Person_ID=m.Staff_ID
            JOIN dbo.PERSON p ON p.Person_ID=s.Person_ID
            WHERE m.Equipment_ID=?
            ORDER BY m.Maintenance_Date DESC, m.Maintenance_ID DESC
        """, (equipment_id,))
        return render_template("maintenance.html", equipment=equipment, rows=rows)
    except Exception:
        flash("Không tải được lịch sử Maintenance.", "error")
        return redirect(url_for("equipment_list"))


@app.route("/borrowings/new", methods=["GET", "POST"])
def borrowing_new():
    try:
        people = fetch_all("SELECT TOP (500) Person_ID, Full_Name FROM dbo.PERSON WHERE Status='ACTIVE' ORDER BY Full_Name")
        equipment = fetch_all("SELECT TOP (500) Equipment_ID, Equipment_Name, Status FROM dbo.EQUIPMENT ORDER BY Equipment_Name")
    except Exception:
        flash("Không tải được dữ liệu biểu mẫu. Kiểm tra kết nối SQL Server.", "error")
        return render_template("borrowing_form.html", people=[], equipment=[])
    if request.method == "POST":
        try:
            person_id = request.form.get("person_id", "").strip()
            equipment_id = request.form.get("equipment_id", "").strip()
            borrow_date = datetime.now().replace(microsecond=0)
            expected = parse_datetime_local(request.form.get("expected_return", ""))
            if expected <= borrow_date:
                raise ValueError("Thời điểm trả dự kiến phải sau thời điểm mượn.")
            with get_connection() as conn:
                cur = conn.cursor()
                require_active_person(cur, person_id)
                cur.execute("""
                    INSERT INTO dbo.BORROWS
                    (Person_ID, Equipment_ID, Borrow_Date, Expected_Return_Date,
                     Actual_Return_Date, Borrow_Status, Return_Condition)
                    VALUES (?, ?, ?, ?, NULL, 'BORROWED', NULL)
                """, person_id, equipment_id, borrow_date, expected)
                conn.commit()
            flash("Đã tạo Borrowing.", "success")
            return redirect(url_for("equipment_list"))
        except ValueError as exc:
            flash(str(exc), "error")
        except Exception as exc:
            flash(safe_db_error(exc), "error")
    return render_template("borrowing_form.html", people=people, equipment=equipment)


def reservation_form(kind: str):
    is_equipment = kind == "equipment"
    table = "RESERVES_EQUIPMENT" if is_equipment else "RESERVES_WORKSTATION"
    resource_field = "Equipment_ID" if is_equipment else "Workstation_ID"
    resource_table = "EQUIPMENT" if is_equipment else "WORKSTATION"
    resource_label = "Equipment" if is_equipment else "Workstation"
    try:
        people = fetch_all("SELECT TOP (500) Person_ID, Full_Name FROM dbo.PERSON WHERE Status='ACTIVE' ORDER BY Full_Name")
        resources = fetch_all(f"SELECT TOP (500) {resource_field} AS Resource_ID, "
                              f"{resource_field} AS Resource_Code, "
                              f"CASE WHEN Status='AVAILABLE' THEN 'AVAILABLE' ELSE Status END AS Status "
                              f"FROM dbo.{resource_table} ORDER BY {resource_field}")
    except Exception:
        flash("Không tải được dữ liệu biểu mẫu. Kiểm tra kết nối SQL Server.", "error")
        return render_template("reservation_form.html", kind=kind, people=[], resources=[], resource_label=resource_label)
    if request.method == "POST":
        try:
            person_id = request.form.get("person_id", "").strip()
            resource_id = request.form.get("resource_id", "").strip()
            start = parse_datetime_local(request.form.get("start_time", ""))
            end = parse_datetime_local(request.form.get("end_time", ""))
            if end <= start:
                raise ValueError("End_Time phải lớn hơn Start_Time.")
            insert_sql = f"INSERT INTO dbo.{table}(Person_ID, {resource_field}, Start_Time, End_Time, Reservation_Status) VALUES (?, ?, ?, ?, 'PENDING')"
            with get_connection() as conn:
                cur = conn.cursor()
                require_active_person(cur, person_id)
                cur.execute(insert_sql, person_id, resource_id, start, end)
                conn.commit()
            flash(f"Đã tạo Reservation cho {resource_label}.", "success")
            return redirect(url_for("equipment_list"))
        except ValueError as exc:
            flash(str(exc), "error")
        except Exception as exc:
            flash(safe_db_error(exc), "error")
    return render_template("reservation_form.html", kind=kind, people=people,
                           resources=resources, resource_label=resource_label)


@app.route("/reservations/equipment/new", methods=["GET", "POST"])
def reserve_equipment():
    return reservation_form("equipment")


@app.route("/reservations/workstation/new", methods=["GET", "POST"])
def reserve_workstation():
    return reservation_form("workstation")


@app.route("/access-attempts/new", methods=["GET", "POST"])
def access_attempt_new():
    try:
        people = fetch_all("SELECT TOP (500) Person_ID, Full_Name FROM dbo.PERSON WHERE Status='ACTIVE' ORDER BY Full_Name")
        equipment = fetch_all("SELECT TOP (500) Equipment_ID, Equipment_Name, Status, Safety_Requirement FROM dbo.EQUIPMENT ORDER BY Equipment_Name")
    except Exception:
        flash("Không tải được dữ liệu biểu mẫu. Kiểm tra kết nối SQL Server.", "error")
        return render_template("access_form.html", people=[], equipment=[])
    if request.method == "POST":
        person_id = request.form.get("person_id", "").strip()
        equipment_id = request.form.get("equipment_id", "").strip()
        action = request.form.get("action", "ACCESS").strip().upper()
        access_time = datetime.now().replace(microsecond=0)
        result = "GRANTED"
        reason = None
        try:
            if action not in {"ACCESS", "USE", "VIEW"}:
                raise ValueError("Action không hợp lệ.")
            with get_connection() as conn:
                cur = conn.cursor()
                require_active_person(cur, person_id)
                cur.execute("SELECT Status, Safety_Requirement FROM dbo.EQUIPMENT WHERE Equipment_ID=?", equipment_id)
                eq = cur.fetchone()
                if not eq:
                    raise ValueError("Không tìm thấy Equipment.")
                eq_status, safety_requirement = eq
                if eq_status != "AVAILABLE":
                    result, reason = "DENIED", "EQUIPMENT_UNAVAILABLE"
                elif safety_requirement != "NONE":
                    cur.execute("""
                        SELECT TOP (1) Certification_ID
                        FROM dbo.CERTIFICATION
                        WHERE Person_ID=? AND Certification_Type=?
                          AND Certification_Status='ACTIVE'
                          AND Issue_Date <= ? AND Expiration_Date >= ?
                        ORDER BY Expiration_Date DESC
                    """, person_id, safety_requirement, access_time.date(), access_time.date())
                    if cur.fetchone() is None:
                        cur.execute("""
                            SELECT TOP (1) Certification_Status, Expiration_Date
                            FROM dbo.CERTIFICATION
                            WHERE Person_ID=? AND Certification_Type=?
                            ORDER BY Expiration_Date DESC, Issue_Date DESC
                        """, person_id, safety_requirement)
                        invalid_cert = cur.fetchone()
                        if invalid_cert is None:
                            reason = "NO_VALID_MATCHING_CERTIFICATION"
                        elif invalid_cert[0] == "SUSPENDED":
                            reason = "CERTIFICATION_SUSPENDED"
                        elif invalid_cert[0] == "REVOKED":
                            reason = "CERTIFICATION_REVOKED"
                        elif invalid_cert[0] == "EXPIRED" or invalid_cert[1] < access_time.date():
                            reason = "CERTIFICATION_EXPIRED"
                        else:
                            reason = "NO_VALID_MATCHING_CERTIFICATION"
                        result = "DENIED"
                cur.execute("""
                    INSERT INTO dbo.ACCESS_LOG
                    (Access_Log_ID, Access_Time, Action, Access_Result, Denial_Reason, Person_ID, Equipment_ID)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, new_access_log_id(), access_time, action, result, reason, person_id, equipment_id)
                conn.commit()
            flash(f"Access Attempt được ghi nhận: {result}.", "success" if result == "GRANTED" else "error")
            return redirect(url_for("access_logs"))
        except ValueError as exc:
            flash(str(exc), "error")
        except Exception as exc:
            flash(safe_db_error(exc), "error")
    return render_template("access_form.html", people=people, equipment=equipment)


@app.get("/access-logs")
def access_logs():
    try:
        rows = fetch_all("""
            SELECT TOP (200) a.Access_Log_ID, a.Access_Time, p.Full_Name,
                   e.Equipment_Name, a.Action, a.Access_Result, a.Denial_Reason
            FROM dbo.ACCESS_LOG a
            JOIN dbo.PERSON p ON p.Person_ID=a.Person_ID
            JOIN dbo.EQUIPMENT e ON e.Equipment_ID=a.Equipment_ID
            ORDER BY a.Access_Time DESC, a.Access_Log_ID DESC
        """)
        return render_template("access_logs.html", rows=rows)
    except Exception:
        flash("Không tải được Access Logs.", "error")
        return render_template("access_logs.html", rows=[])


@app.errorhandler(400)
def bad_request(_error):
    return render_template("error.html", message="Yêu cầu không hợp lệ hoặc CSRF token không hợp lệ."), 400


@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", message="Không tìm thấy trang được yêu cầu."), 404


if __name__ == "__main__":
    host = os.getenv("FLASK_HOST", "127.0.0.1")
    port = int(os.getenv("FLASK_PORT", "5000"))
    debug = os.getenv("FLASK_DEBUG", "no").lower() in {"yes", "true", "1"}
    app.run(host=host, port=port, debug=debug)
