import os
from dotenv import load_dotenv

load_dotenv()


def sql_connection_string() -> str:
    driver = os.getenv("SQL_DRIVER", "ODBC Driver 18 for SQL Server")
    server = os.getenv("SQL_SERVER", "localhost")
    database = os.getenv("SQL_DATABASE", "physics_lab_tracker")
    trusted = os.getenv("SQL_TRUSTED_CONNECTION", "yes").lower() in {"yes", "true", "1"}
    encrypt = os.getenv("SQL_ENCRYPT", "yes")
    trust_cert = os.getenv("SQL_TRUST_SERVER_CERTIFICATE", "yes")

    parts = [
        f"DRIVER={{{driver}}}",
        f"SERVER={server}",
        f"DATABASE={database}",
        f"Encrypt={encrypt}",
        f"TrustServerCertificate={trust_cert}",
    ]
    if trusted:
        parts.append("Trusted_Connection=yes")
    else:
        username = os.getenv("SQL_USERNAME", "")
        password = os.getenv("SQL_PASSWORD", "")
        if not username or not password:
            raise RuntimeError("SQL_USERNAME and SQL_PASSWORD are required when SQL_TRUSTED_CONNECTION=no")
        parts.extend([f"UID={username}", f"PWD={password}"])
    return ";".join(parts) + ";"
