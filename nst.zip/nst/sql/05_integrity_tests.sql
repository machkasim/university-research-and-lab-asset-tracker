/* Integrity and business-rule tests for physics_lab_tracker.
   Prerequisites: run 01_schema.sql and 02_mock_data_bulk.sql.
   Tests use transactions and roll back test rows. TC-16 is read-only.
   Read each PASS / FAIL / REVIEW result in the SSMS Messages tab. */
USE physics_lab_tracker;
GO
SET NOCOUNT ON;
SET XACT_ABORT OFF;
GO

/* TC-01: duplicate primary key. */
PRINT 'TC-01 - Duplicate PERSON primary key';
DECLARE @TC01_Person VARCHAR(20);
SELECT TOP (1) @TC01_Person = Person_ID FROM dbo.PERSON ORDER BY Person_ID;
IF @TC01_Person IS NULL PRINT 'TC-01 REVIEW: PERSON is empty; run mock data first.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.PERSON(Person_ID, Full_Name, Institutional_Email, Department, Status)
    VALUES (@TC01_Person, N'Test duplicate key', 'tc01_duplicate@example.edu', N'Physics', 'ACTIVE');
    PRINT 'TC-01 FAIL: duplicate Person_ID was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC01_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC01_Error IN (2601, 2627) PRINT 'TC-01 PASS: duplicate key rejected by PK/unique constraint.';
    ELSE PRINT CONCAT('TC-01 REVIEW: unexpected error ', @TC01_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-02: invalid foreign key to LABORATORY. */
PRINT 'TC-02 - EQUIPMENT foreign key to LABORATORY';
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.EQUIPMENT
        (Equipment_ID, Equipment_Name, Equipment_Type, Serial_Number, Manufacturer,
         Manufacturing_Year, Acquisition_Date, Status, Safety_Requirement, Lab_ID)
    VALUES ('EQ_TC02', N'Test FK', N'Test Device', 'SN-TC02', N'Test Manufacturer',
            2024, '2024-01-01', 'AVAILABLE', 'NONE', 'LAB_DOES_NOT_EXIST');
    PRINT 'TC-02 FAIL: invalid Lab_ID was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC02_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC02_Error = 547 PRINT 'TC-02 PASS: invalid Lab_ID rejected by foreign key.';
    ELSE PRINT CONCAT('TC-02 REVIEW: unexpected error ', @TC02_Error, ' - ', ERROR_MESSAGE());
END CATCH;
GO

/* TC-03: subtype row must reference an existing PERSON. */
PRINT 'TC-03 - Subtype foreign key';
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.STUDENT(Person_ID) VALUES ('TC_NO_PERSON_0001');
    PRINT 'TC-03 FAIL: orphan subtype was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC03_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC03_Error = 547 PRINT 'TC-03 PASS: orphan subtype rejected by foreign key.';
    ELSE PRINT CONCAT('TC-03 REVIEW: unexpected error ', @TC03_Error, ' - ', ERROR_MESSAGE());
END CATCH;
GO

/* TC-04: Expected_Return_Date must be later than Borrow_Date. */
PRINT 'TC-04 - BORROWS date CHECK';
DECLARE @TC04_Person VARCHAR(20), @TC04_Equipment VARCHAR(20);
SELECT TOP (1) @TC04_Person = Person_ID FROM dbo.PERSON ORDER BY Person_ID;
SELECT TOP (1) @TC04_Equipment = Equipment_ID FROM dbo.EQUIPMENT ORDER BY Equipment_ID;
IF @TC04_Person IS NULL OR @TC04_Equipment IS NULL PRINT 'TC-04 REVIEW: required parent data is missing.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.BORROWS(Person_ID, Equipment_ID, Borrow_Date, Expected_Return_Date,
                            Actual_Return_Date, Borrow_Status, Return_Condition)
    VALUES (@TC04_Person, @TC04_Equipment, '2099-01-02T09:00:00', '2099-01-02T09:00:00',
            NULL, 'BORROWED', NULL);
    PRINT 'TC-04 FAIL: invalid borrowing dates were accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC04_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC04_Error = 547 PRINT 'TC-04 PASS: Expected_Return_Date <= Borrow_Date rejected by CHECK.';
    ELSE PRINT CONCAT('TC-04 REVIEW: unexpected error ', @TC04_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-05: End_Time must be later than Start_Time. */
PRINT 'TC-05 - Reservation time CHECK';
DECLARE @TC05_Person VARCHAR(20), @TC05_Equipment VARCHAR(20);
SELECT TOP (1) @TC05_Person = Person_ID FROM dbo.PERSON ORDER BY Person_ID;
SELECT TOP (1) @TC05_Equipment = Equipment_ID FROM dbo.EQUIPMENT ORDER BY Equipment_ID;
IF @TC05_Person IS NULL OR @TC05_Equipment IS NULL PRINT 'TC-05 REVIEW: required parent data is missing.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.RESERVES_EQUIPMENT(Person_ID, Equipment_ID, Start_Time, End_Time, Reservation_Status)
    VALUES (@TC05_Person, @TC05_Equipment, '2099-02-01T09:00:00', '2099-02-01T09:00:00', 'PENDING');
    PRINT 'TC-05 FAIL: End_Time = Start_Time was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC05_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC05_Error = 547 PRINT 'TC-05 PASS: End_Time <= Start_Time rejected by CHECK.';
    ELSE PRINT CONCAT('TC-05 REVIEW: unexpected error ', @TC05_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-06: open borrowing is blocked for unavailable equipment. */
PRINT 'TC-06 - Borrow unavailable equipment';
DECLARE @TC06_Person VARCHAR(20), @TC06_Equipment VARCHAR(20);
SELECT TOP (1) @TC06_Person = Person_ID FROM dbo.PERSON ORDER BY Person_ID;
SELECT TOP (1) @TC06_Equipment = Equipment_ID FROM dbo.EQUIPMENT
WHERE Status IN ('UNDER_MAINTENANCE','BROKEN','RETIRED') ORDER BY Equipment_ID;
IF @TC06_Person IS NULL OR @TC06_Equipment IS NULL PRINT 'TC-06 REVIEW: no suitable Person or unavailable Equipment.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.BORROWS(Person_ID, Equipment_ID, Borrow_Date, Expected_Return_Date,
                            Actual_Return_Date, Borrow_Status, Return_Condition)
    VALUES (@TC06_Person, @TC06_Equipment, '2098-03-01T09:00:00', '2098-03-03T17:00:00',
            NULL, 'BORROWED', NULL);
    PRINT 'TC-06 FAIL: open borrowing for unavailable equipment was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC06_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC06_Error = 51001 PRINT 'TC-06 PASS: borrowing trigger rejected unavailable equipment.';
    ELSE PRINT CONCAT('TC-06 REVIEW: unexpected error ', @TC06_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-07: active equipment reservations cannot overlap. */
PRINT 'TC-07 - Overlapping equipment reservations';
DECLARE @TC07_Equipment VARCHAR(20), @TC07_Start DATETIME2(0), @TC07_End DATETIME2(0),
        @TC07_ExistingPerson VARCHAR(20), @TC07_TestPerson VARCHAR(20);
SELECT TOP (1) @TC07_Equipment = Equipment_ID, @TC07_Start = Start_Time,
       @TC07_End = End_Time, @TC07_ExistingPerson = Person_ID
FROM dbo.RESERVES_EQUIPMENT
WHERE Reservation_Status IN ('PENDING','APPROVED') ORDER BY Equipment_ID, Start_Time;
SELECT TOP (1) @TC07_TestPerson = Person_ID FROM dbo.PERSON
WHERE Person_ID <> @TC07_ExistingPerson ORDER BY Person_ID DESC;
IF @TC07_Equipment IS NULL OR @TC07_TestPerson IS NULL
    PRINT 'TC-07 REVIEW: no suitable active reservation or test Person was found.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.RESERVES_EQUIPMENT(Person_ID, Equipment_ID, Start_Time, End_Time, Reservation_Status)
    VALUES (@TC07_TestPerson, @TC07_Equipment, DATEADD(MINUTE, 15, @TC07_Start),
            DATEADD(MINUTE, 15, @TC07_End), 'PENDING');
    PRINT 'TC-07 FAIL: overlapping equipment reservation was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC07_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC07_Error = 51002 PRINT 'TC-07 PASS: equipment reservation overlap was rejected.';
    ELSE PRINT CONCAT('TC-07 REVIEW: unexpected error ', @TC07_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-08: active workstation reservations cannot overlap. */
PRINT 'TC-08 - Overlapping workstation reservations';
DECLARE @TC08_Workstation VARCHAR(20), @TC08_Start DATETIME2(0), @TC08_End DATETIME2(0),
        @TC08_ExistingPerson VARCHAR(20), @TC08_TestPerson VARCHAR(20);
SELECT TOP (1) @TC08_Workstation = Workstation_ID, @TC08_Start = Start_Time,
       @TC08_End = End_Time, @TC08_ExistingPerson = Person_ID
FROM dbo.RESERVES_WORKSTATION
WHERE Reservation_Status IN ('PENDING','APPROVED') ORDER BY Workstation_ID, Start_Time;
SELECT TOP (1) @TC08_TestPerson = Person_ID FROM dbo.PERSON
WHERE Person_ID <> @TC08_ExistingPerson ORDER BY Person_ID DESC;
IF @TC08_Workstation IS NULL OR @TC08_TestPerson IS NULL
    PRINT 'TC-08 REVIEW: no suitable active reservation or test Person was found.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.RESERVES_WORKSTATION(Person_ID, Workstation_ID, Start_Time, End_Time, Reservation_Status)
    VALUES (@TC08_TestPerson, @TC08_Workstation, DATEADD(MINUTE, 15, @TC08_Start),
            DATEADD(MINUTE, 15, @TC08_End), 'PENDING');
    PRINT 'TC-08 FAIL: overlapping workstation reservation was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC08_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC08_Error = 51003 PRINT 'TC-08 PASS: workstation reservation overlap was rejected.';
    ELSE PRINT CONCAT('TC-08 REVIEW: unexpected error ', @TC08_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-09: GRANTED requires a valid matching certification. */
PRINT 'TC-09 - GRANTED without matching valid certification';
DECLARE @TC09_Person VARCHAR(20), @TC09_Equipment VARCHAR(20);
SELECT TOP (1) @TC09_Person = p.Person_ID, @TC09_Equipment = e.Equipment_ID
FROM dbo.PERSON AS p CROSS JOIN dbo.EQUIPMENT AS e
WHERE e.Status = 'AVAILABLE' AND e.Safety_Requirement <> 'NONE'
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.CERTIFICATION AS c
      WHERE c.Person_ID = p.Person_ID AND c.Certification_Type = e.Safety_Requirement
        AND c.Certification_Status = 'ACTIVE'
        AND c.Issue_Date <= CONVERT(date, SYSDATETIME())
        AND c.Expiration_Date >= CONVERT(date, SYSDATETIME())
  )
ORDER BY p.Person_ID, e.Equipment_ID;
IF @TC09_Person IS NULL PRINT 'TC-09 REVIEW: no suitable Person/Equipment pair was found.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.ACCESS_LOG(Access_Log_ID, Access_Time, Action, Access_Result, Denial_Reason, Person_ID, Equipment_ID)
    VALUES ('AL_TC09', SYSDATETIME(), 'ACCESS', 'GRANTED', NULL, @TC09_Person, @TC09_Equipment);
    PRINT 'TC-09 FAIL: invalid GRANTED access was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC09_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC09_Error = 51004 PRINT 'TC-09 PASS: trigger rejected GRANTED without matching valid certification.';
    ELSE PRINT CONCAT('TC-09 REVIEW: unexpected error ', @TC09_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-10: DENIED requires a non-NULL reason from the controlled vocabulary. */
PRINT 'TC-10 - DENIED requires a valid Denial_Reason';
DECLARE @TC10_Person VARCHAR(20), @TC10_Equipment VARCHAR(20);
SELECT TOP (1) @TC10_Person = Person_ID FROM dbo.PERSON ORDER BY Person_ID;
SELECT TOP (1) @TC10_Equipment = Equipment_ID FROM dbo.EQUIPMENT ORDER BY Equipment_ID;
IF @TC10_Person IS NULL OR @TC10_Equipment IS NULL PRINT 'TC-10 REVIEW: required parent data is missing.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.ACCESS_LOG(Access_Log_ID, Access_Time, Action, Access_Result, Denial_Reason, Person_ID, Equipment_ID)
    VALUES ('AL_TC10', SYSDATETIME(), 'ACCESS', 'DENIED', NULL, @TC10_Person, @TC10_Equipment);
    PRINT 'TC-10 FAIL: DENIED with NULL reason was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC10_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC10_Error = 547 PRINT 'TC-10 PASS: CHECK rejected DENIED with NULL reason.';
    ELSE PRINT CONCAT('TC-10 REVIEW: unexpected error ', @TC10_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-11: future manufacturing year is rejected by the dynamic trigger. */
PRINT 'TC-11 - Manufacturing year later than current year';
DECLARE @TC11_Lab VARCHAR(20);
SELECT TOP (1) @TC11_Lab = Lab_ID FROM dbo.LABORATORY ORDER BY Lab_ID;
IF @TC11_Lab IS NULL PRINT 'TC-11 REVIEW: LABORATORY is empty.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.EQUIPMENT(Equipment_ID, Equipment_Name, Equipment_Type, Serial_Number, Manufacturer,
                              Manufacturing_Year, Acquisition_Date, Status, Safety_Requirement, Lab_ID)
    VALUES ('EQ_TC11', N'Test future year', N'Test Device', 'SN-TC11', N'Test Manufacturer',
            YEAR(GETDATE()) + 1, '2025-01-01', 'AVAILABLE', 'NONE', @TC11_Lab);
    PRINT 'TC-11 FAIL: future Manufacturing_Year was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC11_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC11_Error = 51005 PRINT 'TC-11 PASS: trigger rejected a year later than the current year.';
    ELSE PRINT CONCAT('TC-11 REVIEW: unexpected error ', @TC11_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-12: an expired matching certification cannot authorize GRANTED. */
PRINT 'TC-12 - Expired matching certification';
DECLARE @TC12_Person VARCHAR(20), @TC12_Equipment VARCHAR(20);
SELECT TOP (1) @TC12_Person = c.Person_ID, @TC12_Equipment = e.Equipment_ID
FROM dbo.CERTIFICATION AS c
JOIN dbo.EQUIPMENT AS e ON e.Safety_Requirement = c.Certification_Type
WHERE c.Certification_Status = 'EXPIRED' AND e.Status = 'AVAILABLE'
ORDER BY c.Person_ID, e.Equipment_ID;
IF @TC12_Person IS NULL PRINT 'TC-12 REVIEW: no expired matching certification pair was found.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.ACCESS_LOG(Access_Log_ID, Access_Time, Action, Access_Result, Denial_Reason, Person_ID, Equipment_ID)
    VALUES ('AL_TC12', SYSDATETIME(), 'ACCESS', 'GRANTED', NULL, @TC12_Person, @TC12_Equipment);
    PRINT 'TC-12 FAIL: expired certification was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC12_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC12_Error = 51004 PRINT 'TC-12 PASS: trigger rejected expired certification.';
    ELSE PRINT CONCAT('TC-12 REVIEW: unexpected error ', @TC12_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-13: reservation is blocked for RETIRED equipment. */
PRINT 'TC-13 - Reservation for RETIRED equipment';
DECLARE @TC13_Person VARCHAR(20), @TC13_Equipment VARCHAR(20);
SELECT TOP (1) @TC13_Person = Person_ID FROM dbo.PERSON ORDER BY Person_ID DESC;
SELECT TOP (1) @TC13_Equipment = Equipment_ID FROM dbo.EQUIPMENT WHERE Status = 'RETIRED' ORDER BY Equipment_ID;
IF @TC13_Person IS NULL OR @TC13_Equipment IS NULL PRINT 'TC-13 REVIEW: no suitable Person or RETIRED Equipment.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.RESERVES_EQUIPMENT(Person_ID, Equipment_ID, Start_Time, End_Time, Reservation_Status)
    VALUES (@TC13_Person, @TC13_Equipment, '2098-04-01T09:00:00', '2098-04-01T11:00:00', 'PENDING');
    PRINT 'TC-13 FAIL: reservation for RETIRED equipment was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC13_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC13_Error = 51009 PRINT 'TC-13 PASS: trigger rejected reservation for RETIRED equipment.';
    ELSE PRINT CONCAT('TC-13 REVIEW: unexpected error ', @TC13_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-14: reservation is blocked for OUT_OF_SERVICE workstation. */
PRINT 'TC-14 - Reservation for OUT_OF_SERVICE workstation';
DECLARE @TC14_Person VARCHAR(20), @TC14_Workstation VARCHAR(20);
SELECT TOP (1) @TC14_Person = Person_ID FROM dbo.PERSON ORDER BY Person_ID DESC;
SELECT TOP (1) @TC14_Workstation = Workstation_ID FROM dbo.WORKSTATION
WHERE Status = 'OUT_OF_SERVICE' ORDER BY Workstation_ID;
IF @TC14_Person IS NULL OR @TC14_Workstation IS NULL PRINT 'TC-14 REVIEW: no suitable Person or OUT_OF_SERVICE Workstation.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.RESERVES_WORKSTATION(Person_ID, Workstation_ID, Start_Time, End_Time, Reservation_Status)
    VALUES (@TC14_Person, @TC14_Workstation, '2098-04-02T09:00:00', '2098-04-02T11:00:00', 'APPROVED');
    PRINT 'TC-14 FAIL: reservation for OUT_OF_SERVICE workstation was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC14_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC14_Error = 51010 PRINT 'TC-14 PASS: trigger rejected reservation for OUT_OF_SERVICE workstation.';
    ELSE PRINT CONCAT('TC-14 REVIEW: unexpected error ', @TC14_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

/* TC-15A: controlled procedure creates each selected subtype. */
PRINT 'TC-15A - Stored procedure creates the requested subtype';
BEGIN TRY
    BEGIN TRANSACTION;
    EXEC dbo.usp_CreatePersonWithSubtype 'T15_STU', N'Test Student', 'tc15_student@example.edu', N'Physics', 'ACTIVE', 'STUDENT';
    EXEC dbo.usp_CreatePersonWithSubtype 'T15_FAC', N'Test Faculty', 'tc15_faculty@example.edu', N'Physics', 'ACTIVE', 'FACULTY';
    EXEC dbo.usp_CreatePersonWithSubtype 'T15_STF', N'Test Lab Staff', 'tc15_staff@example.edu', N'Physics', 'ACTIVE', 'LAB_STAFF';
    IF (SELECT COUNT(*) FROM dbo.STUDENT WHERE Person_ID='T15_STU')=1
       AND (SELECT COUNT(*) FROM dbo.FACULTY WHERE Person_ID='T15_FAC')=1
       AND (SELECT COUNT(*) FROM dbo.LAB_STAFF WHERE Person_ID='T15_STF')=1
       AND (SELECT COUNT(*) FROM dbo.STUDENT WHERE Person_ID='T15_FAC')=0
       AND (SELECT COUNT(*) FROM dbo.FACULTY WHERE Person_ID='T15_STU')=0
       AND (SELECT COUNT(*) FROM dbo.LAB_STAFF WHERE Person_ID='T15_STU')=0
        PRINT 'TC-15A PASS: procedure created exactly the requested subtype records.';
    ELSE PRINT 'TC-15A FAIL: subtype membership differs from the requested subtype.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC15A_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    PRINT CONCAT('TC-15A REVIEW: error ', @TC15A_Error, ' - ', ERROR_MESSAGE());
END CATCH;
GO

/* TC-15B: procedure rejects an invalid subtype. */
PRINT 'TC-15B - Stored procedure rejects invalid subtype';
BEGIN TRY
    EXEC dbo.usp_CreatePersonWithSubtype 'T15_BAD', N'Test Invalid', 'tc15_invalid@example.edu', N'Physics', 'ACTIVE', 'VISITOR';
    PRINT 'TC-15B FAIL: invalid subtype was accepted.';
END TRY
BEGIN CATCH
    DECLARE @TC15B_Error INT = ERROR_NUMBER();
    IF @TC15B_Error = 52001 PRINT 'TC-15B PASS: procedure rejected invalid subtype.';
    ELSE PRINT CONCAT('TC-15B REVIEW: unexpected error ', @TC15B_Error, ' - ', ERROR_MESSAGE());
END CATCH;
GO

/* TC-15C: Disjoint subtype trigger rejects a second subtype for the same PERSON. */
PRINT 'TC-15C - Disjoint subtype enforcement';
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.PERSON(Person_ID, Full_Name, Institutional_Email, Department, Status)
    VALUES ('T15_DIS', N'Test Disjoint', 'tc15_disjoint@example.edu', N'Physics', 'ACTIVE');
    INSERT INTO dbo.STUDENT(Person_ID) VALUES ('T15_DIS');
    INSERT INTO dbo.FACULTY(Person_ID) VALUES ('T15_DIS');
    PRINT 'TC-15C FAIL: PERSON was allowed in two disjoint subtypes.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC15C_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC15C_Error = 51007 PRINT 'TC-15C PASS: second disjoint subtype was rejected.';
    ELSE PRINT CONCAT('TC-15C REVIEW: unexpected error ', @TC15C_Error, ' - ', ERROR_MESSAGE());
END CATCH;
GO

/* TC-16: verify the exact expected DML row counts. */
PRINT 'TC-16 - Verify bulk mock-data row counts';
;WITH Expected AS
(
    SELECT * FROM (VALUES
        ('PERSON',15000), ('STUDENT',9000), ('FACULTY',3000), ('LAB_STAFF',3000),
        ('LABORATORY',5000), ('WORKSTATION',12000), ('EQUIPMENT',12000),
        ('RESEARCH_PROJECT',12000), ('CERTIFICATION',12000), ('MAINTENANCE_RECORD',12000),
        ('PARTICIPATES_IN',24000), ('BORROWS',12000), ('RESERVES_EQUIPMENT',12000),
        ('RESERVES_WORKSTATION',12000), ('ACCESS_LOG',12000)
    ) AS V(TableName, ExpectedRows)
), Actual AS
(
    SELECT 'PERSON' AS TableName, COUNT_BIG(*) AS ActualRows FROM dbo.PERSON
    UNION ALL SELECT 'STUDENT', COUNT_BIG(*) FROM dbo.STUDENT
    UNION ALL SELECT 'FACULTY', COUNT_BIG(*) FROM dbo.FACULTY
    UNION ALL SELECT 'LAB_STAFF', COUNT_BIG(*) FROM dbo.LAB_STAFF
    UNION ALL SELECT 'LABORATORY', COUNT_BIG(*) FROM dbo.LABORATORY
    UNION ALL SELECT 'WORKSTATION', COUNT_BIG(*) FROM dbo.WORKSTATION
    UNION ALL SELECT 'EQUIPMENT', COUNT_BIG(*) FROM dbo.EQUIPMENT
    UNION ALL SELECT 'RESEARCH_PROJECT', COUNT_BIG(*) FROM dbo.RESEARCH_PROJECT
    UNION ALL SELECT 'CERTIFICATION', COUNT_BIG(*) FROM dbo.CERTIFICATION
    UNION ALL SELECT 'MAINTENANCE_RECORD', COUNT_BIG(*) FROM dbo.MAINTENANCE_RECORD
    UNION ALL SELECT 'PARTICIPATES_IN', COUNT_BIG(*) FROM dbo.PARTICIPATES_IN
    UNION ALL SELECT 'BORROWS', COUNT_BIG(*) FROM dbo.BORROWS
    UNION ALL SELECT 'RESERVES_EQUIPMENT', COUNT_BIG(*) FROM dbo.RESERVES_EQUIPMENT
    UNION ALL SELECT 'RESERVES_WORKSTATION', COUNT_BIG(*) FROM dbo.RESERVES_WORKSTATION
    UNION ALL SELECT 'ACCESS_LOG', COUNT_BIG(*) FROM dbo.ACCESS_LOG
)
SELECT E.TableName, E.ExpectedRows, A.ActualRows,
       CASE WHEN A.ActualRows = E.ExpectedRows THEN 'PASS' ELSE 'FAIL' END AS TestResult
FROM Expected AS E JOIN Actual AS A ON A.TableName = E.TableName
ORDER BY E.TableName;
GO

/* TC-17: GRANTED is rejected when equipment is unavailable, even if a matching
   valid certification exists. This tests the Equipment status branch. */
PRINT 'TC-17 - GRANTED access to unavailable equipment';
DECLARE @TC17_Person VARCHAR(20), @TC17_Equipment VARCHAR(20);
SELECT TOP (1) @TC17_Person = c.Person_ID, @TC17_Equipment = e.Equipment_ID
FROM dbo.EQUIPMENT AS e
JOIN dbo.CERTIFICATION AS c ON c.Certification_Type = e.Safety_Requirement
WHERE e.Status IN ('UNDER_MAINTENANCE','BROKEN','RETIRED')
  AND e.Safety_Requirement <> 'NONE'
  AND c.Certification_Status = 'ACTIVE'
  AND c.Issue_Date <= CONVERT(date, SYSDATETIME())
  AND c.Expiration_Date >= CONVERT(date, SYSDATETIME())
ORDER BY e.Equipment_ID, c.Person_ID;
IF @TC17_Person IS NULL PRINT 'TC-17 REVIEW: no unavailable Equipment with a valid matching holder was found.';
ELSE
BEGIN
    BEGIN TRY
    BEGIN TRANSACTION;
    INSERT INTO dbo.ACCESS_LOG(Access_Log_ID, Access_Time, Action, Access_Result, Denial_Reason, Person_ID, Equipment_ID)
    VALUES ('AL_TC17', SYSDATETIME(), 'ACCESS', 'GRANTED', NULL, @TC17_Person, @TC17_Equipment);
    PRINT 'TC-17 FAIL: GRANTED access to unavailable equipment was accepted.';
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    DECLARE @TC17_Error INT = ERROR_NUMBER();
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF @TC17_Error = 51004 PRINT 'TC-17 PASS: trigger rejected GRANTED because equipment was unavailable.';
    ELSE PRINT CONCAT('TC-17 REVIEW: unexpected error ', @TC17_Error, ' - ', ERROR_MESSAGE());
END CATCH;
END;
GO

PRINT 'Finished TC-01 through TC-17. A REVIEW means preconditions were not met or an unexpected error occurred; investigate before reporting PASS.';
GO
