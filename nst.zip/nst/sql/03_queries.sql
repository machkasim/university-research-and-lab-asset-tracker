USE physics_lab_tracker;
GO

-- Q1: Equipment available by laboratory (JOIN + filter)
SELECT l.Lab_Name, e.Equipment_ID, e.Equipment_Name, e.Equipment_Type
FROM dbo.LABORATORY AS l
JOIN dbo.EQUIPMENT AS e ON e.Lab_ID = l.Lab_ID
WHERE e.Status = 'AVAILABLE'
ORDER BY l.Lab_Name, e.Equipment_Name;
GO

-- Q2: Equipment and maintenance history (multiple JOINs)
SELECT e.Equipment_ID, e.Equipment_Name, m.Maintenance_Date,
       m.Maintenance_Type, m.Maintenance_Result, p.Full_Name AS Staff_Name
FROM dbo.EQUIPMENT AS e
JOIN dbo.MAINTENANCE_RECORD AS m ON m.Equipment_ID = e.Equipment_ID
JOIN dbo.LAB_STAFF AS s ON s.Person_ID = m.Staff_ID
JOIN dbo.PERSON AS p ON p.Person_ID = s.Person_ID
ORDER BY e.Equipment_ID, m.Maintenance_Date DESC;
GO

-- Q3: Open and overdue borrowings (JOIN + filter)
SELECT p.Full_Name, e.Equipment_Name, b.Borrow_Date,
       b.Expected_Return_Date, b.Borrow_Status
FROM dbo.BORROWS AS b
JOIN dbo.PERSON AS p ON p.Person_ID = b.Person_ID
JOIN dbo.EQUIPMENT AS e ON e.Equipment_ID = b.Equipment_ID
WHERE b.Actual_Return_Date IS NULL
  AND b.Borrow_Status IN ('BORROWED','OVERDUE')
ORDER BY b.Expected_Return_Date;
GO

-- Q4: Count borrowings per person (GROUP BY + HAVING)
SELECT p.Person_ID, p.Full_Name, COUNT_BIG(*) AS Borrowing_Count
FROM dbo.PERSON AS p
JOIN dbo.BORROWS AS b ON b.Person_ID = p.Person_ID
GROUP BY p.Person_ID, p.Full_Name
HAVING COUNT_BIG(*) >= 1
ORDER BY Borrowing_Count DESC;
GO

-- Q5: Equipment with no maintenance record (NOT EXISTS)
SELECT e.Equipment_ID, e.Equipment_Name
FROM dbo.EQUIPMENT AS e
WHERE NOT EXISTS (
    SELECT 1
    FROM dbo.MAINTENANCE_RECORD AS m
    WHERE m.Equipment_ID = e.Equipment_ID
);
GO

-- Q6: Active certifications and holders (JOIN + date validation)
SELECT p.Person_ID, p.Full_Name, c.Certification_Type, c.Expiration_Date
FROM dbo.PERSON AS p
JOIN dbo.CERTIFICATION AS c ON c.Person_ID = p.Person_ID
WHERE c.Certification_Status = 'ACTIVE'
  AND c.Issue_Date <= CONVERT(date, SYSDATETIME())
  AND c.Expiration_Date >= CONVERT(date, SYSDATETIME())
ORDER BY c.Expiration_Date;
GO

-- Q7: Denied access attempts (JOIN + filtering)
SELECT a.Access_Time, p.Full_Name, e.Equipment_Name, a.Action, a.Denial_Reason
FROM dbo.ACCESS_LOG AS a
JOIN dbo.PERSON AS p ON p.Person_ID = a.Person_ID
JOIN dbo.EQUIPMENT AS e ON e.Equipment_ID = a.Equipment_ID
WHERE a.Access_Result = 'DENIED'
ORDER BY a.Access_Time DESC;
GO

-- Q8: Project members and project supervisor (multiple JOINs)
SELECT rp.Project_ID, rp.Project_Name, sup.Full_Name AS Supervisor,
       member.Full_Name AS Project_Member, pi.Role, pi.Join_Date
FROM dbo.RESEARCH_PROJECT AS rp
JOIN dbo.PERSON AS sup ON sup.Person_ID = rp.Supervisor_ID
JOIN dbo.PARTICIPATES_IN AS pi ON pi.Project_ID = rp.Project_ID
JOIN dbo.PERSON AS member ON member.Person_ID = pi.Person_ID
ORDER BY rp.Project_ID, pi.Join_Date;
GO

-- Q9: Projects with budget above the overall average (scalar subquery)
SELECT Project_ID, Project_Name, Budget
FROM dbo.RESEARCH_PROJECT
WHERE Budget > (SELECT AVG(Budget) FROM dbo.RESEARCH_PROJECT)
ORDER BY Budget DESC;
GO

-- Q10: Reservation demand by equipment (LEFT JOIN + aggregation)
SELECT e.Equipment_ID, e.Equipment_Name,
       COUNT_BIG(r.Start_Time) AS Reservation_Count
FROM dbo.EQUIPMENT AS e
LEFT JOIN dbo.RESERVES_EQUIPMENT AS r ON r.Equipment_ID = e.Equipment_ID
GROUP BY e.Equipment_ID, e.Equipment_Name
ORDER BY Reservation_Count DESC;
GO

-- Q11: Required certification types with no currently certified holder (NOT EXISTS)
SELECT e.Equipment_ID, e.Equipment_Name, e.Safety_Requirement
FROM dbo.EQUIPMENT AS e
WHERE e.Safety_Requirement <> 'NONE'
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.CERTIFICATION AS c
      WHERE c.Certification_Type = e.Safety_Requirement
        AND c.Certification_Status = 'ACTIVE'
        AND c.Issue_Date <= CONVERT(date, SYSDATETIME())
        AND c.Expiration_Date >= CONVERT(date, SYSDATETIME())
  );
GO

-- Q12: Maintenance count and latest maintenance date per equipment (LEFT JOIN + aggregation)
SELECT e.Equipment_ID, e.Equipment_Name,
       COUNT_BIG(m.Maintenance_ID) AS Maintenance_Count,
       MAX(m.Maintenance_Date) AS Latest_Maintenance_Date
FROM dbo.EQUIPMENT AS e
LEFT JOIN dbo.MAINTENANCE_RECORD AS m ON m.Equipment_ID = e.Equipment_ID
GROUP BY e.Equipment_ID, e.Equipment_Name
ORDER BY Maintenance_Count DESC, e.Equipment_ID;
GO
