USE physics_lab_tracker;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF EXISTS (SELECT 1 FROM dbo.PERSON)
   OR EXISTS (SELECT 1 FROM dbo.STUDENT)
   OR EXISTS (SELECT 1 FROM dbo.FACULTY)
   OR EXISTS (SELECT 1 FROM dbo.LAB_STAFF)
   OR EXISTS (SELECT 1 FROM dbo.LABORATORY)
   OR EXISTS (SELECT 1 FROM dbo.WORKSTATION)
   OR EXISTS (SELECT 1 FROM dbo.EQUIPMENT)
   OR EXISTS (SELECT 1 FROM dbo.RESEARCH_PROJECT)
   OR EXISTS (SELECT 1 FROM dbo.CERTIFICATION)
   OR EXISTS (SELECT 1 FROM dbo.MAINTENANCE_RECORD)
   OR EXISTS (SELECT 1 FROM dbo.PARTICIPATES_IN)
   OR EXISTS (SELECT 1 FROM dbo.BORROWS)
   OR EXISTS (SELECT 1 FROM dbo.RESERVES_EQUIPMENT)
   OR EXISTS (SELECT 1 FROM dbo.RESERVES_WORKSTATION)
   OR EXISTS (SELECT 1 FROM dbo.ACCESS_LOG)
BEGIN
    THROW 52000, 'Bulk mock-data script expects empty tables. Use a clean test database or reset it first.', 1;
END;
GO

BEGIN TRY
    BEGIN TRANSACTION;

    CREATE TABLE #N (n INT NOT NULL PRIMARY KEY);
    INSERT INTO #N(n)
    SELECT TOP (15000)
           ROW_NUMBER() OVER (ORDER BY (SELECT NULL))
    FROM sys.all_objects AS a
    CROSS JOIN sys.all_objects AS b;

    IF (SELECT COUNT_BIG(*) FROM #N) <> 15000
        THROW 52003, 'Could not generate the required 15,000 sequence rows.', 1;

    /* 1) Supertype and subtypes: every PERSON is inserted into exactly one subtype. */
    INSERT INTO dbo.PERSON(Person_ID, Full_Name, Institutional_Email, Department, Status)
    SELECT 'P' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6),
           CONCAT(N'User ', n),
           CONCAT('user', n, '@sample.university.edu'),
           CASE n % 5 WHEN 0 THEN N'Physics' WHEN 1 THEN N'Applied Physics'
                    WHEN 2 THEN N'Engineering' WHEN 3 THEN N'Electronics'
                    ELSE N'Physical Sciences' END,
           CASE WHEN n % 100 < 80 THEN 'ACTIVE'
                WHEN n % 100 < 95 THEN 'INACTIVE'
                ELSE 'SUSPENDED' END
    FROM #N;

    INSERT INTO dbo.STUDENT(Person_ID)
    SELECT 'P' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6)
    FROM #N WHERE n BETWEEN 1 AND 9000;

    INSERT INTO dbo.FACULTY(Person_ID)
    SELECT 'P' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6)
    FROM #N WHERE n BETWEEN 9001 AND 12000;

    INSERT INTO dbo.LAB_STAFF(Person_ID)
    SELECT 'P' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6)
    FROM #N WHERE n BETWEEN 12001 AND 15000;

    /* 2) Laboratory: 5,000 synthetic laboratory records. */
    INSERT INTO dbo.LABORATORY(Lab_ID, Lab_Name, Location, Capacity, Responsible_Department)
    SELECT 'LAB' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6),
           CONCAT(N'Physics Laboratory ', n),
           CONCAT(N'Building ', CHAR(65 + (n % 8)), N' - Room ', 100 + (n % 300)),
           20 + (n % 41),
           CASE n % 4 WHEN 0 THEN N'Department of Physics'
                     WHEN 1 THEN N'Applied Physics Department'
                     WHEN 2 THEN N'Electronics Department'
                     ELSE N'Engineering Department' END
    FROM #N WHERE n <= 5000;

    /* 3) Workstations. A small percentage are unavailable for status tests. */
    INSERT INTO dbo.WORKSTATION
        (Workstation_ID, Workstation_Name, Location, Status, Description, Lab_ID)
    SELECT 'WS' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6),
           CONCAT(N'Workstation ', n),
           CONCAT(N'Bench ', 1 + (n % 6)),
           CASE WHEN n % 50 = 0 THEN 'UNDER_MAINTENANCE'
                WHEN n % 50 = 1 THEN 'OUT_OF_SERVICE'
                ELSE 'AVAILABLE' END,
           CONCAT(N'Synthetic workstation record ', n),
           'LAB' + RIGHT('000000' + CONVERT(VARCHAR(6), ((n - 1) % 5000) + 1), 6)
    FROM #N WHERE n <= 12000;

    /* 4) Equipment. Serial_Number is NULL on every tenth row; non-NULL serials are unique. */
    INSERT INTO dbo.EQUIPMENT
        (Equipment_ID, Equipment_Name, Equipment_Type, Serial_Number, Manufacturer,
         Manufacturing_Year, Acquisition_Date, Status, Safety_Requirement, Lab_ID)
    SELECT 'EQ' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6),
           CASE n % 6 WHEN 0 THEN N'Oscilloscope' WHEN 1 THEN N'Digital Multimeter'
                     WHEN 2 THEN N'Function Generator' WHEN 3 THEN N'Laser Source'
                     WHEN 4 THEN N'Power Supply' ELSE N'Optical Bench' END,
           CASE n % 4 WHEN 0 THEN N'Measurement Device' WHEN 1 THEN N'Optics Device'
                      WHEN 2 THEN N'Power Equipment' ELSE N'Laboratory Instrument' END,
           CASE WHEN n % 10 = 0 THEN NULL
                ELSE 'SN-EQ-' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6) END,
           CASE n % 5 WHEN 0 THEN N'Tektronix' WHEN 1 THEN N'Fluke'
                     WHEN 2 THEN N'Keysight' WHEN 3 THEN N'Thorlabs'
                     ELSE N'Edwards' END,
           2000 + (n % 25),
           DATEADD(DAY, 60, DATEFROMPARTS(2000 + (n % 25), 1, 1)),
           CASE WHEN n % 20 = 0 THEN 'RETIRED'
                WHEN n % 20 = 1 THEN 'BROKEN'
                WHEN n % 20 = 2 THEN 'UNDER_MAINTENANCE'
                ELSE 'AVAILABLE' END,
           CASE n % 4 WHEN 0 THEN 'NONE' WHEN 1 THEN 'LASER_SAFETY'
                     WHEN 2 THEN 'RADIATION_SAFETY' ELSE 'HIGH_VOLTAGE_SAFETY' END,
           'LAB' + RIGHT('000000' + CONVERT(VARCHAR(6), ((n - 1) % 5000) + 1), 6)
    FROM #N WHERE n <= 12000;

    /* 5) Research projects. Supervisor_ID always references FACULTY. */
    INSERT INTO dbo.RESEARCH_PROJECT
        (Project_ID, Project_Name, Project_Type, Funding_Source, Start_Date,
         End_Date, Budget, Project_Status, Supervisor_ID)
    SELECT 'PRJ' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6),
           CONCAT(N'University Physics Research Project ', n),
           CASE n % 3 WHEN 0 THEN N'EXPERIMENTAL' WHEN 1 THEN N'APPLIED_RESEARCH'
                      ELSE N'THEORETICAL' END,
           CASE n % 4 WHEN 0 THEN N'University Grant' WHEN 1 THEN N'Government Grant'
                      WHEN 2 THEN N'Faculty Research Fund' ELSE NULL END,
           CASE WHEN n % 4 = 0 THEN DATEADD(DAY, n % 1100, CONVERT(DATE, '2021-01-01'))
                WHEN n % 4 = 1 THEN DATEADD(DAY, n % 300, CONVERT(DATE, '2027-01-01'))
                ELSE DATEADD(DAY, n % 700, CONVERT(DATE, '2024-01-01')) END,
           CASE WHEN n % 4 = 0
                THEN DATEADD(DAY, 365, DATEADD(DAY, n % 1100, CONVERT(DATE, '2021-01-01')))
                WHEN n % 4 = 1
                THEN DATEADD(DAY, 365, DATEADD(DAY, n % 300, CONVERT(DATE, '2027-01-01')))
                ELSE NULL END,
           CONVERT(DECIMAL(14,2), 1000000 + (n % 500) * 25000),
           CASE WHEN n % 4 = 0 THEN 'COMPLETED'
                WHEN n % 4 = 1 THEN 'PLANNED' ELSE 'ONGOING' END,
           'P' + RIGHT('000000' + CONVERT(VARCHAR(6), 9001 + ((n - 1) % 3000)), 6)
    FROM #N WHERE n <= 12000;

    /* 6) Certifications: ACTIVE rows have a valid date window through 2027. */
    INSERT INTO dbo.CERTIFICATION
        (Certification_ID, Certification_Type, Issue_Date, Expiration_Date,
         Certification_Status, Person_ID)
    SELECT 'CERT' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6),
           CASE n % 3 WHEN 0 THEN 'LASER_SAFETY' WHEN 1 THEN 'RADIATION_SAFETY'
                     ELSE 'HIGH_VOLTAGE_SAFETY' END,
           DATEADD(YEAR, -2, CONVERT(DATE, GETDATE())),
           CASE WHEN n % 4 = 0 THEN DATEADD(DAY, -30, CONVERT(DATE, GETDATE()))
                ELSE DATEADD(YEAR, 2, CONVERT(DATE, GETDATE())) END,
           CASE WHEN n % 4 = 0 THEN 'EXPIRED'
                WHEN n % 4 = 1 THEN 'SUSPENDED'
                WHEN n % 4 = 2 THEN 'REVOKED'
                WHEN n % 3 = 2 THEN 'REVOKED'
                ELSE 'ACTIVE' END,
           'P' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6)
    FROM #N WHERE n <= 12000;

    /* 7) Maintenance records: 12,000 rows are distributed across the first
       11,000 equipment records. Thus 1,000 equipment records have no history
       for Q5, while the first 1,000 equipment records have two history rows. */
    INSERT INTO dbo.MAINTENANCE_RECORD
        (Maintenance_ID, Maintenance_Date, Maintenance_Type, Description,
         Next_Maintenance_Date, Maintenance_Result, Equipment_ID, Staff_ID)
    SELECT 'MT' + RIGHT('000000' + CONVERT(VARCHAR(6), n.n), 6),
           DATEADD(DAY, 30 + (n.n % 600), e.Acquisition_Date),
           CASE n.n % 3 WHEN 0 THEN 'INSPECTION' WHEN 1 THEN 'PREVENTIVE' ELSE 'CORRECTIVE' END,
           CONCAT(N'Synthetic maintenance activity ', n.n),
           DATEADD(DAY, 180, DATEADD(DAY, 30 + (n.n % 600), e.Acquisition_Date)),
           CASE WHEN e.Status = 'RETIRED' THEN 'OUT_OF_SERVICE'
                WHEN e.Status IN ('BROKEN','UNDER_MAINTENANCE') THEN 'NEEDS_REPAIR'
                ELSE 'PASSED' END,
           e.Equipment_ID,
           'P' + RIGHT('000000' + CONVERT(VARCHAR(6), 12001 + ((n.n - 1) % 3000)), 6)
    FROM #N AS n
    JOIN dbo.EQUIPMENT AS e
    ON e.Equipment_ID = 'EQ' + RIGHT('000000' + CONVERT(VARCHAR(6), ((n.n - 1) % 11000) + 1), 6)
    WHERE n.n <= 12000;

    /* 8) Participation: two unique people per project -> 24,000 relationship rows. */
    INSERT INTO dbo.PARTICIPATES_IN(Person_ID, Project_ID, Role, Join_Date)
    SELECT 'P' + RIGHT('000000' + CONVERT(VARCHAR(6), ((n - 1) % 9000) + 1), 6),
           'PRJ' + RIGHT('000000' + CONVERT(VARCHAR(6), ((n - 1) % 12000) + 1), 6),
           N'Student Researcher',
           DATEADD(DAY, n % 900, CONVERT(DATE, '2023-01-01'))
    FROM #N WHERE n <= 12000
    UNION ALL
    SELECT 'P' + RIGHT('000000' + CONVERT(VARCHAR(6), 9001 + ((n - 1) % 3000)), 6),
           'PRJ' + RIGHT('000000' + CONVERT(VARCHAR(6), n), 6),
           N'Supervisor',
           DATEADD(DAY, n % 900, CONVERT(DATE, '2023-01-01'))
    FROM #N WHERE n <= 12000;

    /* 9) Borrowings: only AVAILABLE equipment is selected.
       OVERDUE rows have a past expected-return date; BORROWED rows have a future due date. */
    ;WITH AvailableEquipment AS
    (
        SELECT Equipment_ID, ROW_NUMBER() OVER (ORDER BY Equipment_ID) AS rn,
               COUNT(*) OVER () AS cnt
        FROM dbo.EQUIPMENT WHERE Status = 'AVAILABLE'
    )
    INSERT INTO dbo.BORROWS
        (Person_ID, Equipment_ID, Borrow_Date, Expected_Return_Date,
         Actual_Return_Date, Borrow_Status, Return_Condition)
    SELECT 'P' + RIGHT('000000' + CONVERT(VARCHAR(6), n.n), 6),
           ae.Equipment_ID,
           CASE WHEN n.n % 10 = 0
                THEN DATEADD(HOUR, 9, DATEADD(DAY, -10, CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE()))))
                WHEN n.n % 5 = 0
                THEN DATEADD(HOUR, 9, DATEADD(DAY, -1, CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE()))))
                ELSE DATEADD(HOUR, 9, DATEADD(DAY, -(30 + (n.n % 900)), CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE())))) END,
           CASE WHEN n.n % 10 = 0
                THEN DATEADD(HOUR, 17, DATEADD(DAY, -2, CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE()))))
                WHEN n.n % 5 = 0
                THEN DATEADD(HOUR, 17, DATEADD(DAY, 7, CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE()))))
                ELSE DATEADD(HOUR, 17, DATEADD(DAY, -(29 + (n.n % 900)), CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE())))) END,
           CASE WHEN n.n % 5 = 0 THEN NULL
                WHEN n.n % 10 = 0 THEN NULL
                ELSE DATEADD(HOUR, 14, DATEADD(DAY, -(29 + (n.n % 900)), CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE())))) END,
           CASE WHEN n.n % 10 = 0 THEN 'OVERDUE'
                WHEN n.n % 5 = 0 THEN 'BORROWED' ELSE 'RETURNED' END,
           CASE WHEN n.n % 10 = 0 THEN NULL
                WHEN n.n % 5 = 0 THEN NULL
                WHEN n.n % 7 = 0 THEN 'DAMAGED' ELSE 'GOOD' END
    FROM #N AS n
    JOIN AvailableEquipment AS ae
      ON ae.rn = ((n.n - 1) % (SELECT COUNT(*) FROM AvailableEquipment)) + 1
    WHERE n.n <= 12000;

    /* 10) Equipment reservations: repeat resources only in a later, non-overlapping week. */
    ;WITH AvailableEquipment AS
    (
        SELECT Equipment_ID, ROW_NUMBER() OVER (ORDER BY Equipment_ID) AS rn,
               COUNT(*) OVER () AS cnt
        FROM dbo.EQUIPMENT WHERE Status = 'AVAILABLE'
    )
    INSERT INTO dbo.RESERVES_EQUIPMENT
        (Person_ID, Equipment_ID, Start_Time, End_Time, Reservation_Status)
    SELECT 'P' + RIGHT('000000' + CONVERT(VARCHAR(6), n.n), 6),
           ae.Equipment_ID,
           DATEADD(HOUR, 8 + (n.n % 6), DATEADD(DAY, 10 * ((n.n - 1) / (SELECT COUNT(*) FROM AvailableEquipment)) + (n.n % 5), DATEADD(DAY, 30, CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE()))))),
           DATEADD(HOUR, 10 + (n.n % 6), DATEADD(DAY, 10 * ((n.n - 1) / (SELECT COUNT(*) FROM AvailableEquipment)) + (n.n % 5), DATEADD(DAY, 30, CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE()))))),
           CASE WHEN n.n % 20 = 0 THEN 'CANCELLED'
                WHEN n.n % 3 = 0 THEN 'PENDING' ELSE 'APPROVED' END
    FROM #N AS n
    JOIN AvailableEquipment AS ae
      ON ae.rn = ((n.n - 1) % (SELECT COUNT(*) FROM AvailableEquipment)) + 1
    WHERE n.n <= 12000;

    /* 11) Workstation reservations: only AVAILABLE workstations are selected. */
    ;WITH AvailableWorkstations AS
    (
        SELECT Workstation_ID, ROW_NUMBER() OVER (ORDER BY Workstation_ID) AS rn,
               COUNT(*) OVER () AS cnt
        FROM dbo.WORKSTATION WHERE Status = 'AVAILABLE'
    )
    INSERT INTO dbo.RESERVES_WORKSTATION
        (Person_ID, Workstation_ID, Start_Time, End_Time, Reservation_Status)
    SELECT 'P' + RIGHT('000000' + CONVERT(VARCHAR(6), n.n), 6),
           aw.Workstation_ID,
           DATEADD(HOUR, 8 + (n.n % 6), DATEADD(DAY, 10 * ((n.n - 1) / (SELECT COUNT(*) FROM AvailableWorkstations)) + (n.n % 5), DATEADD(DAY, 30, CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE()))))),
           DATEADD(HOUR, 10 + (n.n % 6), DATEADD(DAY, 10 * ((n.n - 1) / (SELECT COUNT(*) FROM AvailableWorkstations)) + (n.n % 5), DATEADD(DAY, 30, CONVERT(DATETIME2(0), CONVERT(DATE, GETDATE()))))),
           CASE WHEN n.n % 20 = 0 THEN 'CANCELLED'
                WHEN n.n % 3 = 0 THEN 'PENDING' ELSE 'APPROVED' END
    FROM #N AS n
    JOIN AvailableWorkstations AS aw
      ON aw.rn = ((n.n - 1) % (SELECT COUNT(*) FROM AvailableWorkstations)) + 1
    WHERE n.n <= 12000;

    /* 12) Access logs:
       GRANTED rows use AVAILABLE equipment with Safety_Requirement='NONE'.
       DENIED rows use AVAILABLE controlled equipment and a person whose matching
       certification is expired, suspended, or revoked; the reason therefore matches the sample data. */
    ;WITH NoSafetyEquipment AS
    (
        SELECT Equipment_ID, ROW_NUMBER() OVER (ORDER BY Equipment_ID) AS rn,
               COUNT(*) OVER () AS cnt
        FROM dbo.EQUIPMENT
        WHERE Safety_Requirement = 'NONE' AND Status = 'AVAILABLE'
    ),
    ControlledEquipment AS
    (
        SELECT Equipment_ID, Safety_Requirement,
               ROW_NUMBER() OVER (PARTITION BY Safety_Requirement ORDER BY Equipment_ID) AS type_rn,
               COUNT(*) OVER (PARTITION BY Safety_Requirement) AS type_count
        FROM dbo.EQUIPMENT
        WHERE Safety_Requirement <> 'NONE' AND Status = 'AVAILABLE'
    ),
    ActivePeople AS
    (
        SELECT Person_ID,
               ROW_NUMBER() OVER (ORDER BY Person_ID) AS rn
        FROM dbo.PERSON
        WHERE Status = 'ACTIVE'
    ),
    InvalidCertificationPeople AS
    (
        SELECT c.Person_ID, c.Certification_Status, c.Certification_Type,
               ROW_NUMBER() OVER (ORDER BY c.Person_ID) AS rn,
               COUNT(*) OVER () AS cnt
        FROM dbo.CERTIFICATION AS c
        JOIN dbo.PERSON AS p ON p.Person_ID = c.Person_ID
        WHERE c.Certification_Status IN ('EXPIRED','SUSPENDED','REVOKED')
          AND p.Status = 'ACTIVE'
    ),
    AccessRows AS
    (
        SELECT n.n,
               CASE WHEN n.n % 2 = 1 THEN 'GRANTED' ELSE 'DENIED' END AS Access_Result,
               CASE WHEN n.n % 2 = 0 THEN (n.n / 2) - 1 ELSE NULL END AS Denied_Sequence
        FROM #N AS n
        WHERE n.n <= 12000
    )
    INSERT INTO dbo.ACCESS_LOG
        (Access_Log_ID, Access_Time, Action, Access_Result, Denial_Reason, Person_ID, Equipment_ID)
    SELECT 'AL' + RIGHT('000000' + CONVERT(VARCHAR(6), a.n), 6),
           DATEADD(MINUTE, -(a.n % 1440), CONVERT(DATETIME2(0), SYSDATETIME())),
           CASE WHEN a.n % 3 = 0 THEN 'USE' ELSE 'ACCESS' END,
           a.Access_Result,
           CASE WHEN a.Access_Result = 'GRANTED' THEN NULL
                WHEN ic.Certification_Status = 'EXPIRED' THEN N'CERTIFICATION_EXPIRED'
                WHEN ic.Certification_Status = 'SUSPENDED' THEN N'CERTIFICATION_SUSPENDED'
                ELSE N'CERTIFICATION_REVOKED' END,
           CASE WHEN a.Access_Result = 'GRANTED'
                THEN ap.Person_ID
                ELSE ic.Person_ID END,
           CASE WHEN a.Access_Result = 'GRANTED' THEN ns.Equipment_ID
                ELSE ce.Equipment_ID END
    FROM AccessRows AS a
    LEFT JOIN ActivePeople AS ap
      ON a.Access_Result = 'GRANTED'
     AND ap.rn = a.n
    LEFT JOIN InvalidCertificationPeople AS ic
      ON a.Access_Result = 'DENIED'
     AND ic.rn = (a.Denied_Sequence % (SELECT COUNT(*) FROM InvalidCertificationPeople)) + 1
    LEFT JOIN ControlledEquipment AS ce
      ON a.Access_Result = 'DENIED'
     AND ce.Safety_Requirement = ic.Certification_Type
     AND ce.type_rn = (a.Denied_Sequence % ce.type_count) + 1
    LEFT JOIN NoSafetyEquipment AS ns
      ON a.Access_Result = 'GRANTED'
     AND ns.rn = ((a.n - 1) % (SELECT COUNT(*) FROM NoSafetyEquipment)) + 1;

    /* Validate the PERSON status mix: 80% ACTIVE, 15% INACTIVE, 5% SUSPENDED. */
    IF (SELECT COUNT(*) FROM dbo.PERSON WHERE Status = 'ACTIVE') <> 12000
       OR (SELECT COUNT(*) FROM dbo.PERSON WHERE Status = 'INACTIVE') <> 2250
       OR (SELECT COUNT(*) FROM dbo.PERSON WHERE Status = 'SUSPENDED') <> 750
        THROW 52004, 'Unexpected PERSON status distribution.', 1;

    /* Every seeded GRANTED access log must reference an ACTIVE person. */
    IF EXISTS
    (
        SELECT 1
        FROM dbo.ACCESS_LOG AS a
        JOIN dbo.PERSON AS p ON p.Person_ID = a.Person_ID
        WHERE a.Access_Result = 'GRANTED'
          AND p.Status <> 'ACTIVE'
    )
        THROW 52005, 'Seeded GRANTED access log references a non-ACTIVE person.', 1;

    /* Validate Total + Disjoint membership for every loaded PERSON. */
    IF EXISTS
    (
        SELECT p.Person_ID
        FROM dbo.PERSON AS p
        LEFT JOIN dbo.STUDENT AS s ON s.Person_ID = p.Person_ID
        LEFT JOIN dbo.FACULTY AS f ON f.Person_ID = p.Person_ID
        LEFT JOIN dbo.LAB_STAFF AS ls ON ls.Person_ID = p.Person_ID
        GROUP BY p.Person_ID
        HAVING COUNT(s.Person_ID) + COUNT(f.Person_ID) + COUNT(ls.Person_ID) <> 1
    )
        THROW 52002, 'Bulk seed failed Total + Disjoint PERSON subtype validation.', 1;

    DROP TABLE #N;
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* Expected total: 155,000 rows. Verify and save this output as evidence for the report. */
SELECT 'PERSON' AS TableName, COUNT_BIG(*) AS TotalRows FROM dbo.PERSON
UNION ALL SELECT 'STUDENT', COUNT_BIG(*) FROM dbo.STUDENT
UNION ALL SELECT 'FACULTY', COUNT_BIG(*) FROM dbo.FACULTY
UNION ALL SELECT 'LAB_STAFF', COUNT_BIG(*) FROM dbo.LAB_STAFF
UNION ALL SELECT 'LABORATORY', COUNT_BIG(*) FROM dbo.LABORATORY
UNION ALL SELECT 'WORKSTATION', COUNT_BIG(*) FROM dbo.WORKSTATION
UNION ALL SELECT 'EQUIPMENT', COUNT_BIG(*) FROM dbo.EQUIPMENT
UNION ALL SELECT 'RESEARCH_PROJECT', COUNT_BIG(*) FROM dbo.RESEARCH_PROJECT
UNION ALL SELECT 'CERTIFICATION', COUNT_BIG(*) FROM dbo.CERTIFICATION
UNION ALL SELECT 'MAINTENANCE_RECORD', COUNT_BIG(*) FROM dbo.MAINTENANCE_RECORD
UNION ALL SELECT 'PARTICIPATES_IN', COUNT_BIG(*) FROM dbo.PARTICIPATES_IN
UNION ALL SELECT 'BORROWS', COUNT_BIG(*) FROM dbo.BORROWS
UNION ALL SELECT 'RESERVES_EQUIPMENT', COUNT_BIG(*) FROM dbo.RESERVES_EQUIPMENT
UNION ALL SELECT 'RESERVES_WORKSTATION', COUNT_BIG(*) FROM dbo.RESERVES_WORKSTATION
UNION ALL SELECT 'ACCESS_LOG', COUNT_BIG(*) FROM dbo.ACCESS_LOG
ORDER BY TableName;
GO
