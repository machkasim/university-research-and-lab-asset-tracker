USE physics_lab_tracker;
GO
SET NOCOUNT ON;
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
GO

/* PT-01: Q1 - available equipment across laboratories (IX_EQUIPMENT_Lab_Status). */
PRINT 'PT-01 warm-up';
SELECT l.Lab_Name, e.Equipment_ID, e.Equipment_Name, e.Equipment_Type
FROM dbo.LABORATORY AS l
JOIN dbo.EQUIPMENT AS e ON e.Lab_ID = l.Lab_ID
WHERE e.Status = 'AVAILABLE'
ORDER BY l.Lab_Name, e.Equipment_Name;
DECLARE @PT01 INT = 1;
WHILE @PT01 <= 5
BEGIN
    PRINT CONCAT('PT-01 measured run ', @PT01);
    SELECT l.Lab_Name, e.Equipment_ID, e.Equipment_Name, e.Equipment_Type
    FROM dbo.LABORATORY AS l
    JOIN dbo.EQUIPMENT AS e ON e.Lab_ID = l.Lab_ID
    WHERE e.Status = 'AVAILABLE'
    ORDER BY l.Lab_Name, e.Equipment_Name;
    SET @PT01 += 1;
END;
GO

/* PT-02: Q2 - maintenance history across equipment (IX_MAINTENANCE_Equipment_Date). */
PRINT 'PT-02 warm-up';
SELECT e.Equipment_ID, e.Equipment_Name, m.Maintenance_Date,
       m.Maintenance_Type, m.Maintenance_Result, p.Full_Name AS Staff_Name
FROM dbo.EQUIPMENT AS e
JOIN dbo.MAINTENANCE_RECORD AS m ON m.Equipment_ID = e.Equipment_ID
JOIN dbo.LAB_STAFF AS s ON s.Person_ID = m.Staff_ID
JOIN dbo.PERSON AS p ON p.Person_ID = s.Person_ID
ORDER BY e.Equipment_ID, m.Maintenance_Date DESC;
DECLARE @PT02 INT = 1;
WHILE @PT02 <= 5
BEGIN
    PRINT CONCAT('PT-02 measured run ', @PT02);
    SELECT e.Equipment_ID, e.Equipment_Name, m.Maintenance_Date,
           m.Maintenance_Type, m.Maintenance_Result, p.Full_Name AS Staff_Name
    FROM dbo.EQUIPMENT AS e
    JOIN dbo.MAINTENANCE_RECORD AS m ON m.Equipment_ID = e.Equipment_ID
    JOIN dbo.LAB_STAFF AS s ON s.Person_ID = m.Staff_ID
    JOIN dbo.PERSON AS p ON p.Person_ID = s.Person_ID
    ORDER BY m.Maintenance_Date DESC;
    SET @PT02 += 1;
END;
GO

/* PT-03: Q7 - latest denied access attempts (IX_ACCESS_Result_Time). */
PRINT 'PT-03 warm-up';
SELECT TOP (200) a.Access_Time, p.Full_Name, e.Equipment_Name,
       a.Action, a.Denial_Reason
FROM dbo.ACCESS_LOG AS a
JOIN dbo.PERSON AS p ON p.Person_ID = a.Person_ID
JOIN dbo.EQUIPMENT AS e ON e.Equipment_ID = a.Equipment_ID
WHERE a.Access_Result = 'DENIED'
ORDER BY a.Access_Time DESC;
DECLARE @PT03 INT = 1;
WHILE @PT03 <= 5
BEGIN
    PRINT CONCAT('PT-03 measured run ', @PT03);
    SELECT TOP (200) a.Access_Time, p.Full_Name, e.Equipment_Name,
           a.Action, a.Denial_Reason
    FROM dbo.ACCESS_LOG AS a
    JOIN dbo.PERSON AS p ON p.Person_ID = a.Person_ID
    JOIN dbo.EQUIPMENT AS e ON e.Equipment_ID = a.Equipment_ID
    WHERE a.Access_Result = 'DENIED'
    ORDER BY a.Access_Time DESC;
    SET @PT03 += 1;
END;
GO

/* PT-04: Q4-style aggregation of borrowing count by equipment. */
PRINT 'PT-04 warm-up';
SELECT e.Equipment_ID, e.Equipment_Name, COUNT_BIG(*) AS Borrowing_Count
FROM dbo.EQUIPMENT AS e
JOIN dbo.BORROWS AS b ON b.Equipment_ID = e.Equipment_ID
GROUP BY e.Equipment_ID, e.Equipment_Name
ORDER BY Borrowing_Count DESC;
DECLARE @PT04 INT = 1;
WHILE @PT04 <= 5
BEGIN
    PRINT CONCAT('PT-04 measured run ', @PT04);
    SELECT e.Equipment_ID, e.Equipment_Name, COUNT_BIG(*) AS Borrowing_Count
    FROM dbo.EQUIPMENT AS e
    JOIN dbo.BORROWS AS b ON b.Equipment_ID = e.Equipment_ID
    GROUP BY e.Equipment_ID, e.Equipment_Name
    ORDER BY Borrowing_Count DESC;
    SET @PT04 += 1;
END;
GO

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO
